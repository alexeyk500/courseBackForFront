export const ErrorCodes = {
  unique: 'E11000'
}